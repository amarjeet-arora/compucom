
import React,{Component} from 'react'
import Option from './Option'


export default class Options extends Component{

render(){

    return (
<div>

    {
this.props.data.map((opt) => <Option text={opt} />)
    }
    

<button onClick={this.props.deletedata}>delete all</button>
    
</div>


    )
}



}

