
import React,{Component} from 'react'
import Header from './Header'
import Options from './Options'
import Action from './Action';
import AddOption from './AddOption';

export default class MainApp extends Component{
constructor(props){
    super(props)

    this.state={
    options:['data1','data2','data3']
    }
}

deleteAllrecords=()=>{
    this.setState(()=>{
        return {
            options:[]
        }
    })
}

addUser=(option) =>{
this.setState((prevState) =>{
    return {
        options:prevState.options.concat(option)
    }
})
}

componentDidMount(){
    console.log('component loaded')
}


componentDidUpdate(){
    console.log('component is updated')
}
render(){

    const headerdata='welcome to header';
   

    return (
<div>
    <p>welcome to mainapp</p>

<Header data={headerdata}/>
<Options data={this.state.options} deletedata={this.deleteAllrecords}/>
    <Action hasData={this.state.options.length >0 }/>
    <AddOption handleAdd={this.addUser}/>
</div>


    )
}



}

