
import React, { Component } from 'react'


export default class AddOption extends Component {
    constructor(props){
   super(props);



    }
    callme=(e)=> {
        e.preventDefault()
        const data = e.target.elements.uname.value.trim()
         const udata= this.props.handleAdd(data)
         
    }

    render() {

        return (
            <div>
                <form onSubmit={this.callme}>
                    Enter your Name:<input type='text' name='uname' />
                    <button>call</button>
                </form>


            </div>


        )
    }



}

