
import React, { Component } from 'react'


const Option = (props) => {
return (
        <div>


            {props.text}
<button onClick={props.deleteone(props.text)}>delete</button>
        </div>


    )
}



export default Option

