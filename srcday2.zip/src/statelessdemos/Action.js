
import React, { Component } from 'react'


export default class Action extends Component {
callme(a){
    a.preventDefault()
    alert('i am activated')
}

    render() {

        return (
            <div>
<form>
<button className="btn btn-success" onClick={this.callme} disabled={!this.props.hasdata}>call</button>
</form>


            </div>


        )
    }



}

