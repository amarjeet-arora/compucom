
import React, { Component } from 'react'
import Header from './Header'
import Options from './Options'
import Action from './Action';
import AddOption from './AddOption';

export default class MainApp extends Component {
    constructor(props) {
        super(props)

        this.state = {
            options: this.props.options
        }
    }

    deleteAllrecords = () => {
        this.setState(() => {
            return {
                options: []
            }
        })
    }

deleteOneRecord=(option)=>{
this.setState((prevState)=>{
    options:prevState.options.filter((opt) => option !== opt)
})
}



    addUser = (option) => {
        this.setState((prevState) => {
            return {
                options: prevState.options.concat(option)
            }
        })
    }

    componentDidMount() {
        try{
const json= localStorage.getItem('options')
const options= JSON.parse(json)
this.setState(()=>({options}))
        }catch(e){}
        console.log('component loaded')
    }


    componentDidUpdate() {
        const json=JSON.stringify(this.state.options)
        localStorage.setItem('options',json)
        console.log('component is updated')
    }
    render() {

        const headerdata = 'welcome to header';


        return (
            <div>
                <p>welcome to mainapp</p>

                <Header data={headerdata} />
                <Options data={this.state.options} deletedata={this.deleteAllrecords} deleteonedata={this.deleteOneRecord}/>
                <Action hasData={this.state.options.length > 0} />
                <AddOption handleAdd={this.addUser} />
            </div>


        )
    }



}
MainApp.defaultProps = {
    options: []
}

