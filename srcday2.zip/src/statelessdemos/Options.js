
import React, { Component } from 'react'
import Option from './Option'


const Options = (props) => {

return (
        <div>

            {
                props.data.map((opt) => <Option text={opt} deleteone={props.deleteonedata}/>)
            }


            <button onClick={props.deletedata}>delete all</button>

        </div>


    )
}
export default Options




