package com.restaurant;

import org.springframework.stereotype.Component;

@Component
public class ItalianReastaurant implements Restaurant{

	@Override
	public String prepareFood(String dish) {
		// TODO Auto-generated method stub
		return "preparing " + dish + "with all italian flavours";
	}

}
