package com.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.restaurant.Restaurant;
@Service
public class GuestService {
	
	@Autowired
	@Qualifier(value = "italianReastaurant")
	private Restaurant restaurant;

	public Restaurant getRestaurant() {
		return restaurant;
	}

	public void setRestaurant(Restaurant restaurant) {
		this.restaurant = restaurant;
	}
	
	
	
	public String takeOrderFromGuest(String foodType) {
		return restaurant.prepareFood(foodType);
	}
	

}
