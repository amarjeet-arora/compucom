package com.client;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

 import com.service.GuestService;

public class AppClient {

	public static void main(String[] args) {

//initialize a container.
		AnnotationConfigApplicationContext ctx= new AnnotationConfigApplicationContext(AppConfig.class);
		
		 GuestService service=(GuestService)ctx.getBean("guestService");
		 
		 System.out.println(service.takeOrderFromGuest("pasta"));
		
	}

}
