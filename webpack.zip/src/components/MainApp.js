import React from 'react'

const MainApp=()=>{

    return(

        <div>
            <h2>welcome to react app</h2>
        </div>
    )

}
export default MainApp