package com.client;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.service.CalculatorService;

public class AppClient {

	public static void main(String[] args) {

//initialize a container.
		AnnotationConfigApplicationContext ctx= new AnnotationConfigApplicationContext(AppConfig.class);
		
		CalculatorService cs=(CalculatorService) ctx.getBean("calculatorService");
		
		System.out.println(cs.service(2340));
		
		//System.out.println(ctx.getBean("calculatorService").hashCode());
		//System.out.println(ctx.getBean("calculatorService").hashCode());
		ctx.destroy();
		
	}

}
