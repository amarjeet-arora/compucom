package com.example.syneBootCore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SyneBootCoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(SyneBootCoreApplication.class, args);
	}

}
