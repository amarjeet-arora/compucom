package com.service;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.model.InterestCalculator;
@Service
//@Scope(value = "prototype")
public class CalculatorService {

	
	@Autowired
	@Qualifier(value = "savingAccount")
	private InterestCalculator ic;

	public InterestCalculator getIc() {
		return ic;
	}

	public void setIc(InterestCalculator ic) {
		this.ic = ic;
	}
	
	public double service(double amount) {
		return ic.calculate(amount);
	}
	CalculatorService(){
		System.out.println("inside Service ");

	}
	
	@PostConstruct
	public void init() {
		System.out.println("inside init");
	}
	@PreDestroy
	public void destroy() {
		System.out.println("inside destroy");
	}
	
	
	
	
	
}
