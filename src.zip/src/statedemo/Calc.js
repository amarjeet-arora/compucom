
import React, { Component } from 'react'


export default class Calc extends Component {

    constructor(props) {
        super(props)
         
        this.state = {
            count: 0
        }
    }
 add=()=> {
this.setState((preState)=>{
    return {
        count:preState.count+1
    }
})
        
    }
    sub=()=> {

        
    }
    reset() {

    
    }

    render() {

        return (
            <div>
                <h3>Count : {this.state.count}</h3>
                <button onClick={this.add}>call</button>
                <button onClick={this.sub}>call</button>
                <button onClick={this.reset}>call</button>



            </div>


        )
    }



}

