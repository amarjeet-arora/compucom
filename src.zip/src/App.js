import logo from './logo.svg';
import './App.css';
import MainApp from './components/MainApp';
 

function App() {
  return (
    <div className="App">
    <p>welcome to react</p>

     <MainApp/>
    </div>
  );
}

export default App;
