
import React, { Component } from 'react'


export default class AddOption extends Component {
    callme(e) {
        e.preventDefault()
        const data = e.target.elements.uname.value.trim()
        alert('the data is' + data)
    }

    render() {

        return (
            <div>
                <form onSubmit={this.callme}>
                    Enter your Name:<input type='text' name='uname' />
                    <button>call</button>
                </form>


            </div>


        )
    }



}

